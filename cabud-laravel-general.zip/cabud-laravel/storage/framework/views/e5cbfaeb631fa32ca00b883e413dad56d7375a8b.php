<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Small boxes (Stat box) -->
    <div class="row">
        <?php echo e('test saja '); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/cabud-laravel/resources/views/user/konten/test.blade.php ENDPATH**/ ?>