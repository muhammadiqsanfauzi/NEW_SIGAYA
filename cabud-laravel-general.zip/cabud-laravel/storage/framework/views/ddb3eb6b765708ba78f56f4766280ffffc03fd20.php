<aside class="main-sidebar sidebar-dark-primary elevation-4">

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
      <div class="image">
        <img src="<?php echo e(asset('assetad/dist/img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <a href="<?php echo e(url('u-profil')); ?>" class="d-block"><?php echo e($user); ?></a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <li class="nav-item">
          <a href="<?php echo e(url('u-beranda')); ?>" class="nav-link <?php if ($judul == 'Beranda') {echo 'active';} ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>Beranda</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(url('u-pengajuan')); ?>" class="nav-link <?php if ($judul == 'Pengajuam') {echo 'active';} ?>">
          <i class="nav-icon fas fa-edit"></i>
            <p>Pengajuan</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(url('u-profil')); ?>" class="nav-link <?php if ($judul == 'Profil Saya') {echo 'active';} ?>">
          <i class="nav-icon fas fa-user"></i>
            <p>Profil</p>
          </a>
        </li>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside><?php /**PATH /opt/lampp/htdocs/cabud-laravel/resources/views/user/include/sidebar.blade.php ENDPATH**/ ?>