<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sicabut | Kabupaten Siak</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/dist/css/adminlte.min.css')); ?>">
    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
</head>

<body class="hold-transition register-page">
    <div class="register-box">
        <div class="card card-outline card-primary">
            <div class="card-header text-center">
                <a href="<?php echo e(url('/')); ?>" class="h1"><b>Sicabut</b></a>
            </div>
            <div class="card-body">
                <!-- <form action="<?php echo e(asset('assetad/index.html')); ?>" method="post" id="registerForm"> -->
                <form action="javascript:void(0)" method="post" id="registerForm">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input name="nama" type="text" class="form-control" placeholder="Nama">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-user"></span>
                            </div>
                        </div>
                    </div>
                    <span id="nama_error" class="text-danger text-sm font-italic"></span>

                    <div class="input-group mt-3">
                        <input name="email" type="email" class="form-control" placeholder="Email">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <span id="email_error" class="text-danger text-sm font-italic"></span>
                    <br>

                    <div class="input-group mt-3">
                        <input name="user" type="text" class="form-control" placeholder="Username">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-at"></span>
                            </div>
                        </div>
                    </div>
                    <span id="user_error" class="text-danger text-sm font-italic"></span>

                    <div class="input-group mt-3">
                        <input name="password" type="password" class="form-control" placeholder="Password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <span id="password_error" class="text-danger text-sm font-italic"></span>

                    <div class="input-group mt-3">
                        <input name="password2" type="password" class="form-control" placeholder="Retype password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <span id="password2_error" class="text-danger text-sm font-italic"></span>

                    <div class="row d-flex justify-content-center mt-3">

                        <div class="col-md-12">
                            <button type="submit" class="btn btn-primary btn-block">Register</button>
                        </div>
                    </div>
                </form>
                <div class="mt-3">
                    <a href="<?php echo e(url('/login')); ?>" class="text-center mt-3">Saya sudah register</a>
                    <br>
                    <a href="<?php echo e(url('/login')); ?>" class="text-center mt-3">Beranda</a>
                </div>
            </div>
        </div>
    </div>
    <!-- /.register-box -->

    <script src="<?php echo e(asset('assetad/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assetad/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assetad/dist/js/adminlte.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assetad/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <script type="text/javascript">
        // $(document).ready(function() {


        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });

        // });

        $('#registerForm').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            $.ajax({
                type: 'POST',
                url: "<?php echo e(url('register')); ?>",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {

                    Toast.fire({
                        icon: 'success',
                        title: 'Data berhasil disimpan.'
                    })

                    setTimeout(location.replace('<?php echo e(url("login")); ?>'), 3000);
                    reset();
                },
                error: function(response) {
                    $('#nama_error').text(response.responseJSON.errors.nama);
                    $('#email_error').text(response.responseJSON.errors.email);
                    $('#user_error').text(response.responseJSON.errors.user);
                    $('#password_error').text(response.responseJSON.errors.password);
                    $('#password2_error').text(response.responseJSON.errors.password2);
                }
            });
        });

        function reset() {
            $('#registerForm').trigger("reset");
            $('#nama_error').html('');
            $('#email_error').html('');
            $('#password_error').html('');
            $('#password2_error').html('');
        }

        var Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000
        });
    </script>
</body>

</html><?php /**PATH /opt/lampp/htdocs/cabud-laravel/resources/views/user/register.blade.php ENDPATH**/ ?>