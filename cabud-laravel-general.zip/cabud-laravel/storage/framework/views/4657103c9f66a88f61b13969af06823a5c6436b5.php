<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sicabut | Kabupaten Siak</title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/plugins/fontawesome-free/css/all.min.css')); ?>">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('assetad/dist/css/adminlte.min.css')); ?>">


</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <style>
            div {
                opacity: 1;
                transition: opacity 300ms;
            }

            div.hide {
                opacity: 0;
            }
        </style>
        <?php if(Session::has('error')): ?>
        <div id="alert" class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Opps!</strong> <?php echo e(Session::get('error')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
        <div class="card card-outline card-primary">
            <div class="card-header text-center">
                <a href="<?php echo e(url('/')); ?>" class="h1"><b>Sicabut</b></a>
            </div>
            <div class="card-body">
                <!-- <p class="login-box-msg">Sign in to start your session</p> -->

                <form action="<?php echo e(url('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mt-4 mb-4">
                        <div class="input-group">
                            <input name="email" type="email" class="form-control" placeholder="Email">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-envelope"></span>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('email')): ?>
                        <span class="text-danger text-sm font-italic"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>

                        <div class="input-group mt-3">
                            <input name="password" type="password" class="form-control" placeholder="Password">
                            <div class="input-group-append">
                                <div class="input-group-text">
                                    <span class="fas fa-lock"></span>
                                </div>
                            </div>
                        </div>
                        <?php if($errors->has('password')): ?>
                        <span class="text-danger text-sm font-italic"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>

                    </div>
                    <div class="row">
                        <div class="col-6">
                            <a href="<?php echo e(url('register')); ?>" class="btn btn-warning btn-block">Register</a>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo e(asset('assetad/plugins/jquery/jquery.min.js')); ?>"></script>
    <!-- Bootstrap 4 -->
    <script src="<?php echo e(asset('assetad/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e(asset('assetad/dist/js/adminlte.min.js')); ?>"></script>
    <script>
        setTimeout(function() {
            document.getElementById('alert').className = 'hide';
        }, 5000);
        $('.alert').alert()
    </script>
</body>

</html><?php /**PATH /opt/lampp/htdocs/cabud-laravel/resources/views/user/login.blade.php ENDPATH**/ ?>