<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Small boxes (Stat box) -->
    <div class="container">
        <div class="row card">
            <div class="card-body">
                <div class="row d-flex justify-content-center mb-3">
                    <img class="rounded m-1" style="min-height: 200px;" src="<?php echo e(asset('assetad/dist/img/user1-128x128.jpg')); ?>" alt="">
                    <img class="rounded m-1" style="min-height: 200px;" src="<?php echo e(asset('assetad/dist/img/user1-128x128.jpg')); ?>" alt="">
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-4">Nama</div>
                            <div class="col-md-8">: <?php echo e($profil->nama); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">NIK</div>
                            <div class="col-md-8">: </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">Kelamin</div>
                            <div class="col-md-8">: </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">Tempat/Tgl lahir</div>
                            <div class="col-md-8">: </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="row">
                            <div class="col-md-4">Alamat</div>
                            <div class="col-md-8">: </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">RT/RW</div>
                            <div class="col-md-8">: </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-4">No Hp</div>
                            <div class="col-md-8">: </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">Email</div>
                            <div class="col-md-8">: </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="d-flex justify-content-center">
                    <?php if($profil->hp == Null): ?>
                    <a class="btn btn-warning mr-1">Lengkapi Profil</a>
                    <?php else: ?>
                    <a class="btn btn-warning mr-1">Edit Profil</a>
                    <?php endif; ?>
                    <a class="btn btn-danger ml-1">Edit User & Password</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/cabud-laravel/resources/views/user/konten/profil.blade.php ENDPATH**/ ?>