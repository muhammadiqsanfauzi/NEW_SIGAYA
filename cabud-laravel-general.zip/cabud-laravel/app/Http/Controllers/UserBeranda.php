<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class UserBeranda extends Controller
{
    public function __construct()
    {
        if (!Auth::guard('web')->check()) {
            redirect('login');
        }
    }

    public function index()
    {
        $data = array(
            'judul' => 'Beranda',
            'user'  => Auth::user()->nama
        );

        return view('user.konten.beranda')->with($data);
    }
}
