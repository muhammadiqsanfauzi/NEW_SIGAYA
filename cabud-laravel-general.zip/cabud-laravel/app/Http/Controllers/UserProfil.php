<?php

namespace App\Http\Controllers;

use App\Models\UserModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserProfil extends Controller
{
    
    public function __construct()
    {
        if (!Auth::check()) {
            redirect('login');
        }
    }
    
    public function index()
    {
        $data = array(
            'judul' => 'Profil Saya',
            'user'  => Auth::user()->nama
        );

        $data['profil'] = UserModel::where(array('id_user' => Auth::user()->id_user))->first();

        return view('user.konten.profil')->with($data);
    }
}
