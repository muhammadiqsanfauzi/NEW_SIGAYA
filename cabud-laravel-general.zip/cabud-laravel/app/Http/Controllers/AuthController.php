<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Http;
use \App\Models\Users;
use Illuminate\Support\Facades\Auth;
use Hash;


class AuthController extends Controller

{
    public function proses_login(Request $request)
    {   

        
        // Login Aplikasi SIMAK / API SIMAK
        $response = Http::withBasicAuth('siaksriindrapura', '514Kr!!NdR4PU124')->withHeaders([
            'SIAK-KEY' => 'NjE2ZTdkNWNjNmVjZTIuODUzODIxODE=SIAKSRIINDRAPURA'])
            ->asForm()->post('103.51.44.173/api/authv2',
            [   
                'username' => $request->username,
                'password' => $request->password,
                'host'     => 'sikompang.siakkab.go.id'
            ]);
        // dd ($response['data']);
        //Update Ke Table User.
        if($response['status']){
            $cek=users::where('username',$request->username)->first();
            if($cek==null){
                users::insert([
                    'name'=>$response['data']['nama_pegawai'],
                    'username'=>$response['data']['id_pegawai'],
                    'password'=>Hash::make($response['data']['id_pegawai']),
                    'level_id'=> $response['data']['tingkatan_level']
                ]);    
            //Jika Gagal Login maka pindah kehalaman login
            }else{
                     users::where('id',$cek->id)->update([
                    'name'=>$response['data']['nama_pegawai'],
                    'username'=>$response['data']['id_pegawai'],
                    'password'=>Hash::make($response['data']['id_pegawai']),
                    'level_id'=> $response['data']['tingkatan_level']
                ]);
            }

                        //Jika Loginnya Berhasil :
                        if (Auth::attempt(['username' => $response['data']['id_pegawai'], 'password' => $response['data']['id_pegawai']])) {
                            $user = Auth::user();
                            // dd(auth::user());
                            if ($user->level_id ==1) {                  //Maka akan pindah kehalaman Superadmin
                                return redirect()->intended('superadmin');
                            } elseif ($user->level_id ==2) {                  //dan jika level koordinatorusers maka akan pindah kehalaman adminteknis
                                return redirect()->intended('adminkantor');
                            } elseif ($user->level_id ==3) {                  //dan jika level admin maka akan pindah kehalaman admindinas
                                return redirect()->intended('operator');
                            }
                           // return redirect()->intended('/');                   //jika tidak keduanya maka akan pindah ke halaman root
            
                        }
                        return redirect('login');  


            //Sesuaikan Dengan Database Kita.
            // if (Auth::attempt(['username' => $response['data']['id_pegawai'], 'password' => $response['data']['id_pegawai']])) {
            // }else{
            // return Redirect('admin');
            // }
        }
    }

         


    public function logout (Request $request) 
    {
         Auth::logout();

    $request->session()->invalidate();

    $request->session()->regenerateToken();

    return redirect('/');
    }

}
